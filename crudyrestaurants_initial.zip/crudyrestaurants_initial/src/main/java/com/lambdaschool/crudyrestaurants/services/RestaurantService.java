package com.lambdaschool.crudyrestaurants.services;

import com.lambdaschool.crudyrestaurants.models.Restaurant;

public interface RestaurantService {
    Restaurant save(Restaurant restaurant);
}
