package com.lambdaschool.crudyrestaurants.services;

import com.lambdaschool.crudyrestaurants.models.Payment;

public interface PaymentService {
    Payment save(Payment payment);
}
