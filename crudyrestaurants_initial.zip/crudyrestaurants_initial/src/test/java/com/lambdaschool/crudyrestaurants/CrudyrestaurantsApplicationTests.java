package com.lambdaschool.crudyrestaurants;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Starting class for testing.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class CrudyrestaurantsApplicationTests
{

    /**
     * The first test. Left empty for now.
     */
    @Test
    public void contextLoads()
    {
    }

}
